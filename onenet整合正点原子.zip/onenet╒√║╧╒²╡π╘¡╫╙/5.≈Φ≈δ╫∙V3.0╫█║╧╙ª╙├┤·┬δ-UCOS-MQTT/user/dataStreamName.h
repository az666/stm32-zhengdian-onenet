﻿char ZW_REDLED[] = "红色LED";
char ZW_BLUELED[] = "蓝色LED";
char ZW_GREENLED[] = "绿色LED";
char ZW_YELLOWLED[] = "黄色LED";

char ZW_TEMPERATURE[] = "温度";
char ZW_HUMIDITY[] = "湿度";

char ZW_BEEP[] = "蜂鸣器";

char ZW_X[] = "X轴";
char ZW_Y[] = "Y轴";
char ZW_Z[] = "Z轴";

char ZW_BG[] = "背光";

char ZW_TIME[] = "实时时间";

char ZW_ERRTYPE[] = "错误类型";
