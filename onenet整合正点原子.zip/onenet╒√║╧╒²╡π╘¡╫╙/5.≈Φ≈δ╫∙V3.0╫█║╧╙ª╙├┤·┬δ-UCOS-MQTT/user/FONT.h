#ifndef _FONT_H_
#define _FONT_H_


extern unsigned char asc2_1206[95][12];
extern const unsigned char asc2_1608[95][16];
extern const unsigned char asc2_2412[95][36];

extern const unsigned char F6x8[][6];
extern const unsigned char F8X16[];


extern const unsigned char wen[];
extern const unsigned char du[];
extern const unsigned char shi[];
extern const unsigned char san[];
extern const unsigned char zhou[];
extern const unsigned char guang[];
extern const unsigned char min[];
extern const unsigned char zhuang[];
extern const unsigned char tai[];
extern const unsigned char wei[];
extern const unsigned char lian[];
extern const unsigned char jie[];
extern const unsigned char zhong[];
extern const unsigned char yi[];
extern const unsigned char duan[];
extern const unsigned char kai[];


#endif
