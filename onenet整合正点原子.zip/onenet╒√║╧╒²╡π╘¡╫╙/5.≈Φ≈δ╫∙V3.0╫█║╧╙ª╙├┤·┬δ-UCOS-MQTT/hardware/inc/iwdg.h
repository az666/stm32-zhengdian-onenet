#ifndef _IWDG_H_
#define _IWDG_H_







void Iwdg_Init(unsigned char psc, unsigned short arr);

void Iwdg_Feed(void);


#endif
