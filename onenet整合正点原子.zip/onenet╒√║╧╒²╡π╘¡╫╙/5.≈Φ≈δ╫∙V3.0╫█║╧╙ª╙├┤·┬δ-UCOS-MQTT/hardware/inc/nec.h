#ifndef _NEC_H_
#define _NEC_H_





void NEC_SendData(unsigned char addr, unsigned char data);

void NEC_SendMultiData(unsigned char *buf, unsigned char num);


#endif
