#ifndef _CLOCK_H_
#define _CLOCK_H_


#include <time.h>


void CLOCK_GetTime(unsigned char *dataPtr, struct tm *localTime);

#endif
